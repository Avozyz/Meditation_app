import 'package:flutter/material.dart';

class MeditationCard extends StatelessWidget {
  final String title;
  final String description;
  final VoidCallback onPressed;

  MeditationCard({
    required this.title,
    required this.description,
    required this.onPressed, required String image,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(16.0),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            Text(description),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: onPressed,
              child: Text('Mulai'),
            ),
          ],
        ),
      ),
    );
  }
}
