import 'package:flutter/material.dart';
import 'dart:async';

class TimerWidget extends StatefulWidget {
  @override
  _TimerWidgetState createState() => _TimerWidgetState();
}

class _TimerWidgetState extends State<TimerWidget> {
  int seconds = 0;
  late Timer _timer;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        seconds++;
      });
    });
  }

  void _stopTimer() {
    _timer.cancel();
  }

  @override
  Widget build(BuildContext context) {
    int minutes = seconds ~/ 60;
    int remainingSeconds = seconds % 60;

    return Column(
      mainAxisAlignment: MainAxisAlignment.center, // Tengahkan vertikal
      crossAxisAlignment: CrossAxisAlignment.center, // Tengahkan horizontal
      children: [
        Text(
          '$minutes menit $remainingSeconds detik',
          style: TextStyle(fontSize: 15.0,),
        ),
        SizedBox(height: 16.0),
        ElevatedButton(
          onPressed: () {
            // Tambahkan logika untuk menghentikan timer
            _stopTimer();
          },
          child: Text('Berhenti'),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }
}
