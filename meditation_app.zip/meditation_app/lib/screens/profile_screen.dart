import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  final String userName; // Variabel untuk nama pengguna
  final String userEmail; // Variabel untuk email pengguna

  ProfileScreen({required this.userName, required this.userEmail});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profil Pengguna', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.amber,
      ),
      body: SingleChildScrollView( // Menggunakan SingleChildScrollView di sini
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/profilpenggunabg.jpeg'),
              fit: BoxFit.cover,
            ),
          ),
          child: LayoutBuilder(
            builder: (context, constraints) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Align(
                      alignment: Alignment.topCenter, // Posisikan ke atas sedikit
                      child: CircleAvatar(
                        radius: constraints.maxWidth * 0.2, // Sesuaikan ukuran avatar dengan lebar layar
                        backgroundImage: AssetImage('assets/meso.png'), // Gambar avatar pengguna
                      ),
                    ),
                    SizedBox(height: 16.0),
                    Text(
                      'Nama Pengguna: $userName',
                      style: TextStyle(fontSize: constraints.maxWidth * 0.03, color: Colors.black),
                    ),
                    SizedBox(height: 8.0),
                    Text(
                      'Email: $userEmail',
                      style: TextStyle(fontSize: constraints.maxWidth * 0.03, color: Colors.black),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
