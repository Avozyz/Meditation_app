import 'package:flutter/material.dart';
import 'dart:async';

class MeditationScreen extends StatefulWidget {
  @override
  _MeditationScreenState createState() => _MeditationScreenState();
}

class _MeditationScreenState extends State<MeditationScreen> {
  bool isMeditating = false;
  int meditationDuration = 0; // Durasi meditasi dalam detik
  late Timer _timer;

  void _startMeditation() {
    setState(() {
      isMeditating = true;
    });

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        meditationDuration++;
      });

      // Misalnya, berhenti setelah 5 menit (300 detik)
      if (meditationDuration >= 300) {
        _stopMeditation();
      }
    });
  }

  void _stopMeditation() {
    setState(() {
      isMeditating = false;
    });

    _timer.cancel();

    // Tambahkan logika untuk menyimpan hasil meditasi atau tindakan lainnya
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Meditasi', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.amber,
      ),
      body: SingleChildScrollView( // Menggunakan SingleChildScrollView di sini
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/meditasipagi2.jpeg'),
              fit: BoxFit.cover,
            ),
          ),
          child: LayoutBuilder(
            builder: (context, constraints) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Meditasi Pagi',
                      style: TextStyle(
                        fontSize: 24.0,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: 16.0),
                    Text(
                      'Membuat Pagi Hari Menjadi lebih relax',
                      style: TextStyle(fontSize: 18.0, color: Colors.black),
                    ),
                    SizedBox(height: 16.0),
                    if (isMeditating)
                      Text(
                        'Durasi Meditasi: ${meditationDuration ~/ 60} menit ${meditationDuration % 60} detik',
                        style: TextStyle(fontSize: 18.0, color: Colors.black),
                      ),
                    SizedBox(height: 16.0),
                    ElevatedButton(
                      onPressed: () {
                        if (isMeditating) {
                          _stopMeditation();
                        } else {
                          _startMeditation();
                        }
                      },
                      child: Text(isMeditating ? 'Berhenti Meditasi' : 'Mulai Meditasi'),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
