import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class JournalScreen extends StatefulWidget {
  @override
  _JournalScreenState createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> {
  TextEditingController _journalController = TextEditingController();
  List<String> journalEntries = []; // Daftar catatan jurnal

  @override
  void initState() {
    super.initState();
    _loadJournalEntries();
  }

  void _loadJournalEntries() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      journalEntries = prefs.getStringList('journalEntries') ?? [];
    });
  }

  void _saveJournalEntry(String entry) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    journalEntries.add(entry);
    prefs.setStringList('journalEntries', journalEntries);
  }

  void _deleteJournalEntry(int index) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    journalEntries.removeAt(index);
    prefs.setStringList('journalEntries', journalEntries);
  }

  @override
  void dispose() {
    _journalController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Jurnal', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.amber,
      ),
      body: SingleChildScrollView( // Menggunakan SingleChildScrollView di sini
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/jurnalmeditasi2.jpeg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Buat Catatan Jurnal',
                  style: TextStyle(
                    fontSize: 24.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                SizedBox(height: 16.0),
                TextField(
                  controller: _journalController,
                  maxLines: 5,
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                    hintText: 'Tulis catatan meditasi Anda di sini...',
                    hintStyle: TextStyle(color: Colors.black),
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16.0),
                ElevatedButton(
                  onPressed: () {
                    String entry = _journalController.text;
                    if (entry.isNotEmpty) {
                      _saveJournalEntry(entry);
                      _journalController.clear();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Catatan telah disimpan ke jurnal.'),
                        ),
                      );
                    }
                  },
                  child: Text('Simpan'),
                ),
                SizedBox(height: 16.0),
                ListView.builder(
                  shrinkWrap: true, // Tambahkan shrinkWrap di sini
                  itemCount: journalEntries.length,
                  itemBuilder: (context, index) {
                    return Dismissible(
                      key: Key(journalEntries[index]), // Key unik untuk setiap catatan
                      onDismissed: (direction) {
                        // Hapus catatan jurnal
                        _deleteJournalEntry(index);
                      },
                      background: Container(
                        color: Colors.red, // Warna latar belakang saat menghapus
                        child: Icon(
                          Icons.delete,
                          color: Colors.white,
                        ),
                        alignment: Alignment.centerRight,
                        padding: EdgeInsets.only(right: 16.0),
                      ),
                      child: ListTile(
                        title: Text(journalEntries[index], style: TextStyle(color: Colors.black)),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
