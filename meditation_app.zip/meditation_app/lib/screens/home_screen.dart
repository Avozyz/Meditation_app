import 'package:flutter/material.dart';
import 'package:meditation_app/widgets/timer_widget.dart';
import 'package:meditation_app/screens/journal_screen.dart';
import 'package:meditation_app/screens/meditation_screen.dart';
import 'package:meditation_app/screens/breath_counter_screen.dart';
import 'package:meditation_app/screens/specific_meditation_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text(
          'Meowditasi App',
          style: TextStyle(color: Colors.black),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.amber,
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              title: Text('Profil Pengguna'),
              onTap: () {
                // Tambahkan logika untuk menampilkan profil pengguna
                Navigator.pushNamed(context, '/profile');
              },
            ),
            ListTile(
              title: Text('Keluar'),
              onTap: () {
                // Tambahkan logika untuk keluar dan kembali ke halaman login
                Navigator.pushReplacementNamed(context, '/carousel');
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView( // Menggunakan SingleChildScrollView di sini
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/kucingbg2.jpeg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Column(
            children: [
              // Bagian Meditasi Pagi (ListView)
              Card(
                child: ListTile(
                  title: Text('Meditasi Pagi'),
                  subtitle: Text('Mulai hari Anda dengan tenang.'),
                  onTap: () {
                    // Navigasi ke halaman MeditationScreen
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MeditationScreen(),
                      ),
                    );
                  },
                ),
              ),

              // Bagian sisanya (GridView)
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true, // Tambahkan shrinkWrap di sini
                children: [
                  // Timer Widget (Card)
                  Card(
                    child: TimerWidget(
                      // Konfigurasi widget timer
                    ),
                  ),

                  // Jurnal Meditasi
                  GestureDetector(
                    onTap: () {
                      // Navigasi ke halaman JournalScreen
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => JournalScreen(),
                        ),
                      );
                    },
                    child: Card(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.book, size: 50),
                          Text('Jurnal Meditasi'),
                        ],
                      ),
                    ),
                  ),

                  // Meditasi Khusus
                  GestureDetector(
                    onTap: () {
                      // Navigasi ke halaman SpecificMeditationScreen
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => SpecificMeditationScreen(
                            meditationName: 'Meditasi Khusus',
                            meditationDuration: 600,
                          ),
                        ),
                      );
                    },
                    child: Card(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.calendar_today, size: 50),
                          Text('Meditasi Khusus'),
                        ],
                      ),
                    ),
                  ),

                  // Hitung Napas
                  GestureDetector(
                    onTap: () {
                      // Navigasi ke halaman BreathCounterScreen
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BreathCounterScreen(),
                        ),
                      );
                    },
                    child: Card(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.air, size: 50),
                          Text('Hitung Napas'),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
