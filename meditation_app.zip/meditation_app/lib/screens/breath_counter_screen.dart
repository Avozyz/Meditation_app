import 'package:flutter/material.dart';
import 'dart:async';

class BreathCounterScreen extends StatefulWidget {
  @override
  _BreathCounterScreenState createState() => _BreathCounterScreenState();
}

class _BreathCounterScreenState extends State<BreathCounterScreen> {
  int breathCount = 0;
  late Timer _timer;

  @override
  void initState() {
    super.initState();
    _startBreathCounter();
  }

  void _startBreathCounter() {
    _timer = Timer.periodic(Duration(seconds: 2), (timer) {
      setState(() {
        breathCount++;
      });
    });
  }

  void _stopBreathCounter() {
    _timer.cancel();
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text('Hitung Napas', style: TextStyle(color: Colors.black)),
      ),
      body: SingleChildScrollView( // Menggunakan SingleChildScrollView di sini
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/hitungnapas3.jpeg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Jumlah Napas',
                  style: TextStyle(
                      fontSize: 24.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.black),
                ),
                SizedBox(height: screenHeight * 0.02), // Adjust spacing based on screen height
                Text(
                  '$breathCount Napas',
                  style: TextStyle(fontSize: 18.0, color: Colors.black),
                ),
                SizedBox(height: screenHeight * 0.02), // Adjust spacing based on screen height
                ElevatedButton(
                  onPressed: () {
                    // Tambahkan logika untuk menghentikan penghitung napas
                    _stopBreathCounter();
                  },
                  child: Text('Berhenti'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
