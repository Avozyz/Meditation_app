import 'package:flutter/material.dart';
import 'dart:async';

class SpecificMeditationScreen extends StatefulWidget {
  final String meditationName;
  final int meditationDuration; // Durasi meditasi dalam detik

  SpecificMeditationScreen({
    required this.meditationName,
    required this.meditationDuration,
  });

  @override
  _SpecificMeditationScreenState createState() =>
      _SpecificMeditationScreenState();
}

class _SpecificMeditationScreenState extends State<SpecificMeditationScreen> {
  int remainingDuration = 0;
  late Timer _timer;

  @override
  void initState() {
    super.initState();
    remainingDuration = widget.meditationDuration;
    _startMeditationTimer();
  }

  void _startMeditationTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        if (remainingDuration > 0) {
          remainingDuration--;
        } else {
          _stopMeditation();
        }
      });
    });
  }

  void _stopMeditation() {
    _timer.cancel();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Selesai Meditasi?'),
          content: Text('Anda ingin menyelesaikan sesi meditasi ini?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Tutup dialog
              },
              child: Text('Batal'),
            ),
            TextButton(
              onPressed: () {
                // Tambahkan logika untuk menyelesaikan meditasi di sini
                Navigator.of(context).pop(); // Tutup dialog
                Navigator.of(context).pop(); // Kembali ke halaman sebelumnya
              },
              child: Text('Selesai'),
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Meditasi: ${widget.meditationName}', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.amber,
      ),
      body: SingleChildScrollView( // Menggunakan SingleChildScrollView di sini
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/meditasikhusus2.jpeg'),
              fit: BoxFit.cover,
            ),
          ),
          child: LayoutBuilder(
            builder: (context, constraints) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Sesi Meditasi: ${widget.meditationName}',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: constraints.maxWidth * 0.07, // Sesuaikan ukuran teks
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: 16.0),
                    Text(
                      'Durasi Tersisa: $remainingDuration detik',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: constraints.maxWidth * 0.05, // Sesuaikan ukuran teks
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: 16.0),
                    ElevatedButton(
                      onPressed: () {
                        _stopMeditation();
                      },
                      child: Text('Selesai Meditasi', textAlign: TextAlign.center,),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
