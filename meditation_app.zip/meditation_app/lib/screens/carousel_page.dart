import 'package:flutter/material.dart';

class CarouselPage extends StatelessWidget {
  final String image;
  final String description;
  final String buttonText;
  final Function()? onNext;
  final String textAboveButton;

  CarouselPage({
    required this.image,
    required this.description,
    required this.buttonText,
    required this.textAboveButton,
    this.onNext,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage(image),
          fit: BoxFit.cover,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          TextButton(
            onPressed: () {
              if (onNext != null) {
                onNext!();
              }
            },
            child: Text(
              textAboveButton,
              style: TextStyle(
                color: Colors.black, // Atur warna teks menjadi hitam
                decoration: TextDecoration.none, // Hapus dekorasi teks
                fontSize: 20,
                fontWeight: FontWeight.bold
              ),
            ),
          ),
          SizedBox(height: 480),
          ElevatedButton(
            onPressed: () {
              if (onNext != null) {
                onNext!();
              }
            },
            child: Text(buttonText),
          ),
          SizedBox(height: 50)
        ],
      ),
    );
  }
}
