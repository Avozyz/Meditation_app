import 'package:flutter/material.dart';
import 'package:meditation_app/screens/home_screen.dart';
import 'carousel_page.dart'; // Anda perlu mengimpor 'carousel_page.dart'

class CarouselScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView( // Menggunakan SingleChildScrollView di sini
        child: Column( // Menggunakan Column untuk menata konten secara vertikal
          children: [
            buildCarouselPage(
              context,
              'assets/kucing10.jpeg',
              'Halaman 1',
              'Selanjutnya',
              'Jangan Lupa Meditasi Pagi',
              () {
                navigateToNextPage(
                  context,
                  'assets/kucing7.jpeg',
                  'Halaman 2',
                  'Selanjutnya',
                  'Mulailah Jurnal Meditasi mu',
                  () {
                    navigateToNextPage(
                      context,
                      'assets/kucing7.jpeg',
                      'Halaman 3',
                      'Selanjutnya',
                      'Lakukan lah Meditasi Khusus',
                      () {
                        navigateToNextPage(
                          context,
                          'assets/kucing7.jpeg',
                          'Halaman 4',
                          'Selamat Datang',
                          'Hitunglah Setiap Napasmu',
                          () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen()));
                          },
                        );
                      },
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget buildCarouselPage(
    BuildContext context,
    String image,
    String description,
    String buttonText,
    String textAboveButton,
    Function() onNext,
  ) {
    return CarouselPage(
      image: image,
      description: description,
      buttonText: buttonText,
      textAboveButton: textAboveButton,
      onNext: onNext,
    );
  }

  void navigateToNextPage(
    BuildContext context,
    String image,
    String description,
    String buttonText,
    String textAboveButton,
    Function() onNext,
  ) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => buildCarouselPage(context, image, description, buttonText, textAboveButton, onNext)));
  }
}
