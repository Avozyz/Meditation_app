import 'package:flutter/material.dart';
import 'package:meditation_app/screens/breath_counter_screen.dart';
import 'package:meditation_app/screens/home_screen.dart';
import 'package:meditation_app/screens/journal_screen.dart';
import 'package:meditation_app/screens/meditation_screen.dart';
import 'package:meditation_app/screens/profile_screen.dart';
import 'package:meditation_app/screens/specific_meditation_screen.dart';
import 'package:meditation_app/screens/carousel_screen.dart';
// Impor halaman profil pengguna

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Meowditasi App',
      theme: ThemeData.dark(
      ),
      initialRoute: '/carousel', // Rute awal ke halaman utama
      routes: {
        '/home': (context) => HomeScreen(), // Rute ke halaman utama
        '/meditation': (context) => MeditationScreen(), // Rute ke halaman meditasi
        '/journal': (context) => JournalScreen(), // Rute ke halaman jurnal
        '/breath_counter': (context) => BreathCounterScreen(), // Rute ke halaman penghitung napas
        '/profile': (context) => ProfileScreen(
            userName: 'Nezon', userEmail: 'nezonzen@gmail.com'), // Rute ke halaman profil pengguna
        '/specific_meditation': (context) => SpecificMeditationScreen(
        meditationName: 'Meditasi Pilihan',
        meditationDuration: 300,),
         '/carousel': (context) => CarouselScreen(), // Durasi meditasi dalam detik
     // Rute ke halaman sesi meditasi khusus
      },
    );
  }
}
